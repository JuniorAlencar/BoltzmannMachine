#include "exp_means.h"

int main(){
    


}