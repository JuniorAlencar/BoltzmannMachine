#include "exp_means.h"

int main(){
	string filename	= "sampleCarmona";
	double min_erro_j	= 1.0e-04;
	double min_erro_h	= 2.0e-04;
	int multiply_teq 	= 300;
	int multiply_relx 	= 2;
	string method = "exact";
        exp_mean_calculate emc;
        exp_means ep;
	ep = emc.exp_calculate(filename);
}
