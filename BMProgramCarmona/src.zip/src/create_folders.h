#ifndef CREATE_FOLDERS_H
#define CREATE_FOLDERS_H

// Create folders Results and Results Metropolis
void create_folders();

#endif // EXACT_SOLUTION_H