#ifndef READ_JSON_H
#define READ_JSON_H

#include <nlohmann/json.hpp>
#include "network.h"

Rede read_json(const std::string filename);


#endif //READ_JSON_H