#ifndef INITIAL_GUESS_H
#define INITIAL_GUESS_H

#include "network.h"

void read_initial_guess(const std::string filename, Rede& bm);

#endif